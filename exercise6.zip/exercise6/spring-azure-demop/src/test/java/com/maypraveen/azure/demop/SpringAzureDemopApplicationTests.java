package com.maypraveen.azure.demop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAzureDemopApplicationTests {

	@Test
	void contextLoads() {
	}

}
